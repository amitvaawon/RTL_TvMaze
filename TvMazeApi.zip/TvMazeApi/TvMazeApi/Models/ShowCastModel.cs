﻿using System;
using System.Collections.Generic;

namespace TvMazeApi.Models
{
    public class ShowCastModel
    {
        public class ShowCast
        {
            public int id { get; set; }
            public string name { get; set; }
            public _Embedded _embedded { get; set; }
        }
        public class _Embedded
        {
            public List<Cast> cast { get; set; }

        }
        public class Cast
        {
            public Person person { get; set; }
        }

        public class Person
        {
            public int id { get; set; }
            public string name { get; set; }

            public string birthday { get; set; }
        }
    }

    public class ResultData
    {
        public class Rootobject
        {
            public int id { get; set; }
            public string name { get; set; }
            public List<Cast> cast { get; set; }
        }


        public class Cast
        {
            public int id { get; set; }
            public string name { get; set; }

            public string birthday { get; set; }
        }
    }

    public class ShowData
    {
        public class Rootobject
        {
            public Shows[] show { get; set; }
        }

        public class Shows
        {
            public int id { get; set; }
        }
    }
}
