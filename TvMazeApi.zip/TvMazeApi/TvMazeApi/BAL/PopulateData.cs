﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TvMazeApi.Models;
using static TvMazeApi.Models.ShowCastModel;

namespace TvMazeApi.BAL
{
    public class PopulateData
    {
        /// <summary>
        /// Populating data from TVAMAZE API
        /// </summary>
        /// <param name="scObj"></param>
        /// <returns></returns>
        public ResultData.Rootobject GenerateData(ShowCast scObj)
        {
            try
            {
                List<ResultData.Rootobject> lstobj = new List<ResultData.Rootobject>();
                ResultData.Rootobject obj = new ResultData.Rootobject();
                List<ResultData.Cast> lstcast = new List<ResultData.Cast>();
                obj.id = scObj.id;
                obj.name = scObj.name;
                foreach (var item in scObj._embedded.cast)
                {
                    ResultData.Cast c = new ResultData.Cast();
                    c.id = item.person.id;
                    c.name = item.person.name;
                    c.birthday = item.person.birthday!=null ? Convert.ToDateTime(item.person.birthday).Date.ToString("yyyy-MM-dd") : Convert.ToDateTime("01/01/0001").Date.ToString("yyyy-mm-dd");
                    lstcast.Add(c);
                }
                obj.cast = lstcast.OrderByDescending(t=>t.birthday).ToList();
                return obj;
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
