﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using TvMazeApi.BAL;
using TvMazeApi.Models;
using TvMazeApi.Utilities;
using static TvMazeApi.Models.ShowCastModel;

namespace TvMazeApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ShowsCastController : ControllerBase
    {
        /// <summary>
        /// Store ShowsCast Data into JSON file
        /// </summary>
        /// <returns></returns>
        [HttpGet("[action]")]
        public IActionResult StoreShowsCastData()
        {
            ApiResponse apiResponseObj = new ApiResponse();
            PopulateData populateDataObj = new PopulateData();
            List<ResultData.Rootobject> lstresultData = new List<ResultData.Rootobject>();
            ResultData.Rootobject resultDataObj = new ResultData.Rootobject();
            JSONReadWrite readWrite = new JSONReadWrite();

            //Clean Json Data from existing file
            readWrite.Write("showcast.json", "Data", "");


            string showcontent = apiResponseObj.Get("http://api.tvmaze.com/shows");
            List<ShowData.Shows> objShowData = JsonConvert.DeserializeObject<List<ShowData.Shows>>(showcontent);
            foreach (var item in objShowData)
            {
                string content = apiResponseObj.Get("http://api.tvmaze.com/shows/" + item.id + "?embed=cast");
                ShowCast showCastobj = JsonConvert.DeserializeObject<ShowCast>(content);
                resultDataObj = populateDataObj.GenerateData(showCastobj);
                lstresultData.Add(resultDataObj);
            }
            var jSONString = JsonConvert.SerializeObject(lstresultData);

            //Inserting Json Data
            readWrite.Write("showcast.json", "Data", jSONString);
            return Ok();
        }


        /// <summary>
        /// Get shows and cast data by page number and batch size (no of data per page)
        /// </summary>
        /// <param name="pageno"></param>
        /// <param name="batchSzie"></param>
        /// <returns></returns>
        [HttpGet("[action]")]
        public IActionResult Get(int pageno,int batchSize)
        {
            JSONReadWrite readWrite = new JSONReadWrite();
            List<ResultData.Rootobject> lstobj = new List<ResultData.Rootobject>();

            string ret=readWrite.Read("showcast.json", "Data");
            lstobj = JsonConvert.DeserializeObject<List<ResultData.Rootobject>>(ret);
            int skip = (pageno-1) * batchSize;
            var finallst = lstobj.Skip(skip).Take(batchSize).ToList();

            var json = JsonConvert.SerializeObject(finallst);
            return Ok(json);
        }
    }
}