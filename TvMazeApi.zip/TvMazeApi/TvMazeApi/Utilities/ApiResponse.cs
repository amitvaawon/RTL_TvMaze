﻿using System.IO;
using System.Net;

namespace TvMazeApi.Utilities
{
    public class ApiResponse
    {
        /// <summary>
        /// Calling REST Api
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public string Get(string url)
        {
            var request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = "Get";
            var response = (HttpWebResponse)request.GetResponse();
            string content = string.Empty;

            using (var stream = response.GetResponseStream())
            {
                using (var sr = new StreamReader(stream))
                {
                    content = sr.ReadToEnd();
                }
            }

            return content;
        }
    }
}
