﻿using System.IO;

namespace TvMazeApi.Utilities
{
    public class JSONReadWrite
    {
        public JSONReadWrite() { }

        /// <summary>
        /// Read the JSON file
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="location"></param>
        /// <returns></returns>
        public string Read(string fileName, string location)
        {
            var path = Path.Combine(
            Directory.GetCurrentDirectory(),
            location,
            fileName);

            string jsonResult;

            using (StreamReader streamReader = new StreamReader(path))
            {
                jsonResult = streamReader.ReadToEnd();
            }
            return jsonResult;
        }


        /// <summary>
        /// Write data into JSON file
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="location"></param>
        /// <param name="jSONString"></param>
        public void Write(string fileName, string location, string jSONString)
        {
            var path = Path.Combine(
            Directory.GetCurrentDirectory(),
            location,
            fileName);

            using (var streamWriter = File.CreateText(path))
            {
                streamWriter.Write(jSONString);
            }
        }
    }
}
